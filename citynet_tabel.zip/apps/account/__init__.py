# from django.apps import AppConfig
#
#
# class AccountAppConfig(AppConfig):
#     name = 'apps.account'
#     label = 'account'
#     verbose_name = 'Account'
#
#
# default_app_config = 'apps.account.AccountAppConfig'
